"use client"

import { useEffect, useRef, useState } from "react"
import { Button } from "@/components/ui/button"

export default function DinoGame() {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [gameStarted, setGameStarted] = useState(false)
  const [gameOver, setGameOver] = useState(false)
  const [score, setScore] = useState(0)
  const [highScore, setHighScore] = useState(0)

  const gameStateRef = useRef({
    dino: {
      x: 50,
      y: 0,
      width: 40,
      height: 50,
      jumping: false,
      velocity: 0,
      gravity: 0.6,
      jumpPower: -12,
    },
    obstacles: [] as Array<{ x: number; width: number; height: number }>,
    clouds: [] as Array<{ x: number; y: number; width: number }>,
    groundY: 0,
    speed: 6,
    score: 0,
    frameCount: 0,
  })

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const game = gameStateRef.current
    game.groundY = canvas.height - 80

    for (let i = 0; i < 3; i++) {
      game.clouds.push({
        x: Math.random() * canvas.width,
        y: 30 + Math.random() * 80,
        width: 60 + Math.random() * 40,
      })
    }

    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === "Space" || e.code === "ArrowUp") {
        e.preventDefault()
        if (!gameStarted) {
          setGameStarted(true)
          setGameOver(false)
          resetGame()
        } else if (!gameOver && !game.dino.jumping) {
          jump()
        } else if (gameOver) {
          restartGame()
        }
      }
    }

    window.addEventListener("keydown", handleKeyPress)

    const jump = () => {
      if (!game.dino.jumping) {
        game.dino.jumping = true
        game.dino.velocity = game.dino.jumpPower
      }
    }

    const resetGame = () => {
      game.dino.y = game.groundY - game.dino.height
      game.dino.jumping = false
      game.dino.velocity = 0
      game.obstacles = []
      game.speed = 6
      game.score = 0
      game.frameCount = 0
      setScore(0)
      setGameOver(false)
    }

    const restartGame = () => {
      setGameStarted(true)
      resetGame()
    }

    const spawnObstacle = () => {
      const minGap = 120
      const lastObstacle = game.obstacles[game.obstacles.length - 1]

      if (!lastObstacle || canvas.width - lastObstacle.x > minGap) {
        const width = 20 + Math.random() * 30
        const height = 40 + Math.random() * 40
        game.obstacles.push({
          x: canvas.width,
          width,
          height,
        })
      }
    }

    const checkCollision = () => {
      const dino = game.dino
      const dinoBottom = dino.y + dino.height
      const dinoRight = dino.x + dino.width

      for (const obstacle of game.obstacles) {
        const obstacleTop = game.groundY - obstacle.height
        const obstacleRight = obstacle.x + obstacle.width

        if (dinoRight > obstacle.x && dino.x < obstacleRight && dinoBottom > obstacleTop && dino.y < game.groundY) {
          return true
        }
      }
      return false
    }

    const drawDino = () => {
      ctx.fillStyle = "#10b981"

      // Body
      ctx.fillRect(game.dino.x, game.dino.y, game.dino.width, game.dino.height - 10)

      // Head
      ctx.fillRect(game.dino.x + 25, game.dino.y - 10, 15, 15)

      // Eye
      ctx.fillStyle = "#000"
      ctx.fillRect(game.dino.x + 32, game.dino.y - 7, 3, 3)

      // Tail
      ctx.fillStyle = "#10b981"
      ctx.fillRect(game.dino.x - 8, game.dino.y + 5, 10, 8)

      // Legs (animated)
      const legAnimation = Math.floor(game.frameCount / 10) % 2
      if (legAnimation === 0) {
        ctx.fillRect(game.dino.x + 5, game.dino.y + game.dino.height - 10, 8, 10)
        ctx.fillRect(game.dino.x + 25, game.dino.y + game.dino.height - 10, 8, 10)
      } else {
        ctx.fillRect(game.dino.x + 10, game.dino.y + game.dino.height - 10, 8, 10)
        ctx.fillRect(game.dino.x + 20, game.dino.y + game.dino.height - 10, 8, 10)
      }
    }

    const drawObstacles = () => {
      game.obstacles.forEach((obstacle) => {
        const obstacleY = game.groundY - obstacle.height

        // Cactus style obstacle
        ctx.fillStyle = "#059669"
        ctx.fillRect(obstacle.x, obstacleY, obstacle.width, obstacle.height)

        // Add spikes
        ctx.fillStyle = "#047857"
        for (let i = 0; i < 3; i++) {
          const spikeX = obstacle.x + (obstacle.width / 4) * i
          ctx.fillRect(spikeX, obstacleY + 5, 5, 10)
        }
      })
    }

    const drawClouds = () => {
      ctx.fillStyle = "#e5e7eb"
      game.clouds.forEach((cloud) => {
        ctx.beginPath()
        ctx.arc(cloud.x, cloud.y, cloud.width / 3, 0, Math.PI * 2)
        ctx.arc(cloud.x + cloud.width / 3, cloud.y - 5, cloud.width / 4, 0, Math.PI * 2)
        ctx.arc(cloud.x + cloud.width / 2, cloud.y, cloud.width / 3, 0, Math.PI * 2)
        ctx.fill()
      })
    }

    const drawGround = () => {
      // Ground line
      ctx.strokeStyle = "#6b7280"
      ctx.lineWidth = 3
      ctx.beginPath()
      ctx.moveTo(0, game.groundY)
      ctx.lineTo(canvas.width, game.groundY)
      ctx.stroke()

      const dashOffset = (game.frameCount * 2) % 40
      ctx.setLineDash([20, 20])
      ctx.lineDashOffset = -dashOffset
      ctx.strokeStyle = "#9ca3af"
      ctx.lineWidth = 2
      ctx.beginPath()
      ctx.moveTo(0, game.groundY + 10)
      ctx.lineTo(canvas.width, game.groundY + 10)
      ctx.stroke()
      ctx.setLineDash([])
    }

    const update = () => {
      if (!gameStarted || gameOver) return

      game.frameCount++

      // Update dino physics
      if (game.dino.jumping || game.dino.y < game.groundY - game.dino.height) {
        game.dino.velocity += game.dino.gravity
        game.dino.y += game.dino.velocity

        if (game.dino.y >= game.groundY - game.dino.height) {
          game.dino.y = game.groundY - game.dino.height
          game.dino.jumping = false
          game.dino.velocity = 0
        }
      }

      game.clouds.forEach((cloud) => {
        cloud.x -= 0.5
        if (cloud.x + cloud.width < 0) {
          cloud.x = canvas.width + 50
          cloud.y = 30 + Math.random() * 80
        }
      })

      // Spawn obstacles
      if (game.frameCount % 100 === 0) {
        spawnObstacle()
      }

      // Update obstacles
      game.obstacles.forEach((obstacle, index) => {
        obstacle.x -= game.speed

        if (obstacle.x + obstacle.width < 0) {
          game.obstacles.splice(index, 1)
          game.score += 10
          setScore(game.score)
        }
      })

      // Increase difficulty
      if (game.frameCount % 500 === 0) {
        game.speed += 0.5
      }

      // Check collision
      if (checkCollision()) {
        setGameOver(true)
        setGameStarted(false)
        if (game.score > highScore) {
          setHighScore(game.score)
          localStorage.setItem("dinoHighScore", game.score.toString())
        }
      }
    }

    const draw = () => {
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height)
      gradient.addColorStop(0, "#bae6fd")
      gradient.addColorStop(1, "#e0f2fe")
      ctx.fillStyle = gradient
      ctx.fillRect(0, 0, canvas.width, canvas.height)

      // Draw game elements
      drawClouds()
      drawGround()
      drawDino()
      drawObstacles()

      // Draw score with shadow effect
      ctx.shadowColor = "rgba(0, 0, 0, 0.2)"
      ctx.shadowBlur = 4
      ctx.shadowOffsetX = 2
      ctx.shadowOffsetY = 2
      ctx.fillStyle = "#1f2937"
      ctx.font = "bold 24px monospace"
      ctx.textAlign = "right"
      ctx.fillText(`SCORE: ${game.score}`, canvas.width - 20, 35)

      if (highScore > 0) {
        ctx.fillText(`HIGH: ${highScore}`, canvas.width - 20, 65)
      }
      ctx.shadowBlur = 0
      ctx.shadowOffsetX = 0
      ctx.shadowOffsetY = 0

      // Draw instructions
      if (!gameStarted && !gameOver) {
        ctx.fillStyle = "rgba(0, 0, 0, 0.7)"
        ctx.fillRect(canvas.width / 2 - 200, canvas.height / 2 - 60, 400, 120)

        ctx.fillStyle = "#fff"
        ctx.font = "bold 28px monospace"
        ctx.textAlign = "center"
        ctx.fillText("DINO RUNNER", canvas.width / 2, canvas.height / 2 - 20)
        ctx.font = "bold 18px monospace"
        ctx.fillText("Press SPACE or CLICK to Start", canvas.width / 2, canvas.height / 2 + 20)
      }

      if (gameOver) {
        ctx.fillStyle = "rgba(239, 68, 68, 0.9)"
        ctx.fillRect(canvas.width / 2 - 200, canvas.height / 2 - 80, 400, 160)

        ctx.fillStyle = "#fff"
        ctx.font = "bold 36px monospace"
        ctx.textAlign = "center"
        ctx.fillText("GAME OVER!", canvas.width / 2, canvas.height / 2 - 30)
        ctx.font = "bold 20px monospace"
        ctx.fillText(`Final Score: ${game.score}`, canvas.width / 2, canvas.height / 2 + 10)
        ctx.font = "bold 18px monospace"
        ctx.fillText("Press SPACE to Restart", canvas.width / 2, canvas.height / 2 + 50)
      }
    }

    const gameLoop = () => {
      update()
      draw()
      requestAnimationFrame(gameLoop)
    }

    // Load high score
    const savedHighScore = localStorage.getItem("dinoHighScore")
    if (savedHighScore) {
      setHighScore(Number.parseInt(savedHighScore))
    }

    gameLoop()

    return () => {
      window.removeEventListener("keydown", handleKeyPress)
    }
  }, [gameStarted, gameOver, highScore])

  const handleCanvasClick = () => {
    if (!gameStarted) {
      setGameStarted(true)
      setGameOver(false)
    } else if (!gameOver && !gameStateRef.current.dino.jumping) {
      gameStateRef.current.dino.jumping = true
      gameStateRef.current.dino.velocity = gameStateRef.current.dino.jumpPower
    } else if (gameOver) {
      setGameStarted(true)
      setGameOver(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-sky-100 via-blue-50 to-cyan-100 p-4">
      <div className="mb-8 text-center">
        <h1 className="text-5xl font-bold text-gray-900 mb-3 tracking-tight">Dino Runner</h1>
        <p className="text-lg text-gray-600">Jump over obstacles and survive as long as you can!</p>
      </div>

      <div className="bg-white rounded-2xl shadow-2xl p-6 border-4 border-gray-200">
        <canvas
          ref={canvasRef}
          width={800}
          height={400}
          className="rounded-lg cursor-pointer"
          onClick={handleCanvasClick}
        />
      </div>

      <div className="mt-8 flex gap-4">
        <Button
          onClick={() => {
            if (!gameStarted) {
              setGameStarted(true)
              setGameOver(false)
            } else if (gameOver) {
              setGameStarted(true)
              setGameOver(false)
            } else {
              if (!gameStateRef.current.dino.jumping) {
                gameStateRef.current.dino.jumping = true
                gameStateRef.current.dino.velocity = gameStateRef.current.dino.jumpPower
              }
            }
          }}
          variant="default"
          size="lg"
          className="px-8 py-6 text-lg font-bold"
        >
          {!gameStarted && !gameOver ? "Start Game" : gameOver ? "Play Again" : "Jump"}
        </Button>
      </div>

      <div className="mt-6 text-center">
        <div className="flex items-center justify-center gap-8 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-gray-200 rounded text-xs font-mono">SPACE</kbd>
            <span>Jump</span>
          </div>
          <div className="flex items-center gap-2">
            <kbd className="px-2 py-1 bg-gray-200 rounded text-xs font-mono">CLICK</kbd>
            <span>Jump</span>
          </div>
        </div>
      </div>
    </div>
  )
}
